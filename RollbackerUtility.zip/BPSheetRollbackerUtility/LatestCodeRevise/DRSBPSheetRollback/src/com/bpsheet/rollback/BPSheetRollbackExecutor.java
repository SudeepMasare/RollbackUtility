package com.bpsheet.rollback;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.bpsheet.rollback.bo.AuditBO;
import com.bpsheet.rollback.bo.Student1BO;
import com.bpsheet.rollback.bo.Student2BO;
import com.bpsheet.rollback.bo.Student3BO;
import com.bpsheet.rollback.configuration.HibernateConfiguration;
import com.bpsheet.rollback.so.BPSheetIdsSO;

/**
 * @author SudeepMasare
 * 
 *         Main Method
 *
 */
public class BPSheetRollbackExecutor {

	static String executorOfBPSheet = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BPSheetRollbackExecutor bpSheetRollbacker = new BPSheetRollbackExecutor();
		Session session = HibernateConfiguration.getSessionFactory().openSession();
		executorOfBPSheet = args[0];
		AuditBO auditBO = isExecutorAvailable(session, executorOfBPSheet);

		if (args[1].equalsIgnoreCase("PRE")) {
			preExecution(bpSheetRollbacker, auditBO, session);
		}

		if (args[1].equalsIgnoreCase("POST")) {
			postExecution(bpSheetRollbacker, auditBO, session);
		}

		if (args[1].equalsIgnoreCase("ROLLBACK")) {
			rollbackBPSheet(executorOfBPSheet, auditBO, session);
		}

		System.exit(0);

	}

	private static AuditBO isExecutorAvailable(Session session, String executoeName) {
		// TODO Auto-generated method stub
		Criteria criteria = session.createCriteria(AuditBO.class);
		criteria.add(Restrictions.eq("executorName", executoeName));
		List<AuditBO> results = criteria.list();
		if (!results.isEmpty()) {
			for (AuditBO auditBO : results) {
				return auditBO;
			}
		}
		return null;
	}

	private static void preExecution(BPSheetRollbackExecutor studentAddressStorage, AuditBO auditBO, Session session) {

		BPSheetIdsSO bpSheetIdsSO = new BPSheetIdsSO();

		/**
		 * 
		 * Following method call will give us Pre-BPSheet Execution Max Ids of all the
		 * tables.
		 * 
		 */
		bpSheetIdsSO = PreBPSheetAllTablesMaxIds(session, bpSheetIdsSO);

		/**
		 * 
		 * In the following method we will check if All the Max columns in Audit table
		 * are null, If all the Max columns are null then that means After the
		 * successful execution of BPSheet, we will be having new Max Ids for all the
		 * BPSheet corresponding table which we have to store in Max column of Audit
		 * table.
		 * 
		 * Remember : Now we have both Min Id = Max Id of tables before BPSheet
		 * execution Remember : & Max Id = Max Id of tables after BPSheet execution
		 * 
		 * This difference is nothing but all those records which belongs to you in case
		 * if you want to run roll-back.
		 * 
		 */

		bpSheetIdsSO = PostBPSheetAuditTableMinIds(session, bpSheetIdsSO);

		if (auditBO == null
				&& (bpSheetIdsSO.getStudent1PostId() == null
						|| (bpSheetIdsSO.getStudent1PreId() > bpSheetIdsSO.getStudent1PostId()))
				&& (bpSheetIdsSO.getStudent2PostId() == null
						|| (bpSheetIdsSO.getStudent2PreId() > bpSheetIdsSO.getStudent2PostId()))
				&& (bpSheetIdsSO.getStudent3PostId() == null
						|| (bpSheetIdsSO.getStudent3PreId() > bpSheetIdsSO.getStudent3PostId()))) {
			auditBO = new AuditBO();
			auditBO.setExecutorName(executorOfBPSheet);
			auditBO.setStudent1MinId(bpSheetIdsSO.getStudent1PreId());
			auditBO.setStudent2MinId(bpSheetIdsSO.getStudent2PreId());
			auditBO.setStudent3MinId(bpSheetIdsSO.getStudent3PreId());

		}

		studentAddressStorage.dataStorageCall(session, auditBO);

		studentAddressStorage.getFilteredRecords(auditBO.getId());

		session.close();
	}

	private static void postExecution(BPSheetRollbackExecutor studentAddressStorage, AuditBO auditBO, Session session) {

		BPSheetIdsSO bpSheetIdsSO = new BPSheetIdsSO();

		/**
		 * 
		 * Following method call will give us Pre-BPSheet Execution Max Ids of all the
		 * tables.
		 * 
		 */
		bpSheetIdsSO = PreBPSheetAllTablesMaxIds(session, bpSheetIdsSO);

		/**
		 * 
		 * In the following method we will check if All the Max columns in Audit table
		 * are null, If all the Max columns are null then that means After the
		 * successful execution of BPSheet, we will be having new Max Ids for all the
		 * BPSheet corresponding table which we have to store in Max column of Audit
		 * table.
		 * 
		 * Remember : Now we have both Min Id = Max Id of tables before BPSheet
		 * execution Remember : & Max Id = Max Id of tables after BPSheet execution
		 * 
		 * This difference is nothing but all those records which belongs to you in case
		 * if you want to run roll-back.
		 * 
		 */

		bpSheetIdsSO = PostBPSheetAuditTableMinIds(session, bpSheetIdsSO);

		if ((auditBO.getId()) != null) {
			auditBO.setStudent1MaxId(bpSheetIdsSO.getStudent1PreId());
			auditBO.setStudent2MaxId(bpSheetIdsSO.getStudent2PreId());
			auditBO.setStudent3MaxId(bpSheetIdsSO.getStudent3PreId());
		}

		studentAddressStorage.dataStorageCall(session, auditBO);

		studentAddressStorage.getFilteredRecords(auditBO.getId());

		session.close();
	}

	private static void rollbackBPSheet(String executorName, AuditBO auditBO, Session session) {
		// TODO Auto-generated method stub

		rollbackFromTable1(executorName, session);
		rollbackFromTable2(executorName, session);
		rollbackFromTable3(executorName, session);
		rollingBackExecutor(executorName, session);

	}

	private static void rollbackFromTable1(String executorName, Session session) {
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<AuditBO> criteriaQuery = builder.createQuery(AuditBO.class);
		Root<AuditBO> sRoot = criteriaQuery.from(AuditBO.class);
		criteriaQuery.select(sRoot).where(builder.equal(sRoot.get("executorName"), executorName));
		List<AuditBO> auditBOs = session.createQuery(criteriaQuery).getResultList();

		if (!auditBOs.isEmpty()) {
			for (AuditBO auditBo : auditBOs) {
				Transaction transaction = session.beginTransaction();
				String hql = "delete from Student1BO where id1 > :min and id1 <= :max";
				session.createQuery(hql).setInteger("min", auditBo.getStudent1MinId())
						.setInteger("max", auditBo.getStudent1MaxId()).executeUpdate();
				System.out.println("Rollback From Table1 Completed");
				transaction.commit();
			}
		}
	}

	private static void rollbackFromTable2(String executorName, Session session) {
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<AuditBO> criteriaQuery = builder.createQuery(AuditBO.class);
		Root<AuditBO> sRoot = criteriaQuery.from(AuditBO.class);
		criteriaQuery.select(sRoot).where(builder.equal(sRoot.get("executorName"), executorName));
		List<AuditBO> auditBOs = session.createQuery(criteriaQuery).getResultList();

		if (!auditBOs.isEmpty()) {
			for (AuditBO auditBo : auditBOs) {
				Transaction transaction = session.beginTransaction();
				String hql = "delete from Student2BO where id2 > :min and id2 <= :max";
				session.createQuery(hql).setInteger("min", auditBo.getStudent2MinId())
						.setInteger("max", auditBo.getStudent2MaxId()).executeUpdate();
				System.out.println("Rollback From Table2 Completed");
				transaction.commit();
			}
		}
	}

	private static void rollbackFromTable3(String executorName, Session session) {
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<AuditBO> criteriaQuery = builder.createQuery(AuditBO.class);
		Root<AuditBO> sRoot = criteriaQuery.from(AuditBO.class);
		criteriaQuery.select(sRoot).where(builder.equal(sRoot.get("executorName"), executorName));
		List<AuditBO> auditBOs = session.createQuery(criteriaQuery).getResultList();

		if (!auditBOs.isEmpty()) {
			for (AuditBO auditBo : auditBOs) {
				Transaction transaction = session.beginTransaction();
				String hql = "delete from Student3BO where id3 > :min and id3 <= :max";
				session.createQuery(hql).setInteger("min", auditBo.getStudent3MinId())
						.setInteger("max", auditBo.getStudent3MaxId()).executeUpdate();
				System.out.println("Rollback From Table3 Completed");
				transaction.commit();
			}
		}
	}

	private static void rollingBackExecutor(String executorName, Session session) {
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<AuditBO> criteriaQuery = builder.createQuery(AuditBO.class);
		Root<AuditBO> sRoot = criteriaQuery.from(AuditBO.class);
		criteriaQuery.select(sRoot).where(builder.equal(sRoot.get("executorName"), executorName));
		List<AuditBO> auditBOs = session.createQuery(criteriaQuery).getResultList();

		if (!auditBOs.isEmpty()) {
			for (AuditBO auditBo : auditBOs) {
				Transaction transaction = session.beginTransaction();
				session.delete(auditBo);
				System.out.println("BPSheet Executor Rolled Back From AUDIT Table");
				transaction.commit();
			}
		}
	}

	private static BPSheetIdsSO PreBPSheetAllTablesMaxIds(Session session, BPSheetIdsSO bpSheetMinMaxIdsSO) {

		DetachedCriteria criteria1 = DetachedCriteria.forClass(Student1BO.class).setProjection(Projections.max("id1"));
		bpSheetMinMaxIdsSO.setStudent1PreId((Integer) criteria1.getExecutableCriteria(session).list().get(0));

		DetachedCriteria criteria2 = DetachedCriteria.forClass(Student2BO.class).setProjection(Projections.max("id2"));
		bpSheetMinMaxIdsSO.setStudent2PreId((Integer) criteria2.getExecutableCriteria(session).list().get(0));

		DetachedCriteria criteria3 = DetachedCriteria.forClass(Student3BO.class).setProjection(Projections.max("id3"));
		bpSheetMinMaxIdsSO.setStudent3PreId((Integer) criteria3.getExecutableCriteria(session).list().get(0));

		return bpSheetMinMaxIdsSO;
	}

	private static BPSheetIdsSO PostBPSheetAuditTableMinIds(Session session, BPSheetIdsSO bpSheetMinMaxIdsSO) {

		DetachedCriteria criteria0 = DetachedCriteria.forClass(AuditBO.class)
				.setProjection(Projections.max("student1MinId"));
		bpSheetMinMaxIdsSO.setStudent1PostId((Integer) criteria0.getExecutableCriteria(session).list().get(0));

		DetachedCriteria criteria1 = DetachedCriteria.forClass(AuditBO.class)
				.setProjection(Projections.max("student2MinId"));
		bpSheetMinMaxIdsSO.setStudent2PostId((Integer) criteria1.getExecutableCriteria(session).list().get(0));

		DetachedCriteria criteria2 = DetachedCriteria.forClass(AuditBO.class)
				.setProjection(Projections.max("student3MinId"));
		bpSheetMinMaxIdsSO.setStudent3PostId((Integer) criteria2.getExecutableCriteria(session).list().get(0));

		return bpSheetMinMaxIdsSO;
	}

	public void dataStorageCall(Session session, AuditBO studentBO) {
		// TODO Auto-generated method stub
		// Session session = HibernateConfiguration.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(studentBO);
		transaction.commit();

	}

	/**
	 * The following method is only for Printing Purpose
	 */
	public void getFilteredRecords(Integer id) {

		Session session = HibernateConfiguration.getSessionFactory().openSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<AuditBO> criteriaQuery = builder.createQuery(AuditBO.class);
		Root<AuditBO> sRoot = criteriaQuery.from(AuditBO.class);
		criteriaQuery.select(sRoot).where(builder.equal(sRoot.get("id"), id));
		List<AuditBO> auditBOs = session.createQuery(criteriaQuery).getResultList();

		if (!auditBOs.isEmpty()) {
			for (AuditBO auditBo : auditBOs) {

				System.out.println("Record ID : ");

				System.out.println(auditBo.getId());

				System.out.println("------------------------------");

				System.out.println("Pre-BPSheet Execution Rollback Min Ids");

				System.out.println(auditBo.getStudent1MinId());
				System.out.println(auditBo.getStudent2MinId());
				System.out.println(auditBo.getStudent3MinId());

				System.out.println("------------------------------");

				System.out.println("Post-BPSheet Execution Rollback Max Ids");

				System.out.println(auditBo.getStudent1MaxId());
				System.out.println(auditBo.getStudent2MaxId());
				System.out.println(auditBo.getStudent3MaxId());
			}
		}

	}
}
