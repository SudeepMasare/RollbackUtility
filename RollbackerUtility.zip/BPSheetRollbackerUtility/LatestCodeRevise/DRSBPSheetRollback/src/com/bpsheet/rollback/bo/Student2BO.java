package com.bpsheet.rollback.bo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STUD_DATA_2")
public class Student2BO implements Serializable {

	/**
	 * CREATE TABLE SM_Hibernate_1.STUD_DATA_2(ID INT(10) NOT NULL
	 * AUTO_INCREMENT,STUD_DATA_VAL VARCHAR(20),PRIMARY KEY(ID)); INSERT INTO
	 * SM_Hibernate_1.STUD_DATA_2(ID,STUD_DATA_VAL)VALUES(10,'KRISHNA'); SELECT *
	 * FROM SM_Hibernate_1.STUD_DATA_2;
	 */
	private static final long serialVersionUID = 5502282322044903500L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer id2;

	public Integer getId2() {
		return id2;
	}

	public void setId2(Integer id2) {
		this.id2 = id2;
	}

}
