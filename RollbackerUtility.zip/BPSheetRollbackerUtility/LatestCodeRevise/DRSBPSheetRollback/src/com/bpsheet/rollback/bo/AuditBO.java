package com.bpsheet.rollback.bo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AUDIT")
public class AuditBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2548758635810472061L;

	/**
	 * CREATE TABLE SM_Hibernate_1.AUDIT(ID INT(10) NOT NULL AUTO_INCREMENT,EXECUTOR
	 * VARCHAR(20) NOT NULL, STUDENT1_MAX INT(10),STUDENT1_MIN INT(10), STUDENT2_MAX
	 * INT(10),STUDENT2_MIN INT(10), STUDENT3_MAX INT(10),STUDENT3_MIN INT(10),
	 * PRIMARY KEY(ID) );
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false, updatable = false)
	private Integer id;

	@Column(name = "EXECUTOR", nullable = false)
	private String executorName;

	@Column(name = "STUDENT1_MAX")
	private Integer student1MaxId;

	@Column(name = "STUDENT1_MIN")
	private Integer student1MinId;

	@Column(name = "STUDENT2_MAX")
	private Integer student2MaxId;

	@Column(name = "STUDENT2_MIN")
	private Integer student2MinId;

	@Column(name = "STUDENT3_MAX")
	private Integer student3MaxId;

	@Column(name = "STUDENT3_MIN")
	private Integer student3MinId;

	public String getExecutorName() {
		return executorName;
	}

	public void setExecutorName(String executorName) {
		this.executorName = executorName;
	}

	public Integer getStudent1MaxId() {
		return student1MaxId;
	}

	public void setStudent1MaxId(Integer student1MaxId) {
		this.student1MaxId = student1MaxId;
	}

	public Integer getStudent1MinId() {
		return student1MinId;
	}

	public void setStudent1MinId(Integer student1MinId) {
		this.student1MinId = student1MinId;
	}

	public Integer getStudent2MaxId() {
		return student2MaxId;
	}

	public void setStudent2MaxId(Integer student2MaxId) {
		this.student2MaxId = student2MaxId;
	}

	public Integer getStudent2MinId() {
		return student2MinId;
	}

	public void setStudent2MinId(Integer student2MinId) {
		this.student2MinId = student2MinId;
	}

	public Integer getStudent3MaxId() {
		return student3MaxId;
	}

	public void setStudent3MaxId(Integer student3MaxId) {
		this.student3MaxId = student3MaxId;
	}

	public Integer getStudent3MinId() {
		return student3MinId;
	}

	public void setStudent3MinId(Integer student3MinId) {
		this.student3MinId = student3MinId;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

}
