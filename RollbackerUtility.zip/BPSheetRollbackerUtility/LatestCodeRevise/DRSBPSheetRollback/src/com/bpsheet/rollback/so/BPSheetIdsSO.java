package com.bpsheet.rollback.so;

public class BPSheetIdsSO {

	private Integer student1PreId;
	private Integer student2PreId;
	private Integer student3PreId;

	private Integer student1PostId;
	private Integer student2PostId;
	private Integer student3PostId;

	public Integer getStudent1PreId() {
		return student1PreId;
	}

	public void setStudent1PreId(Integer student1PreId) {
		this.student1PreId = student1PreId;
	}

	public Integer getStudent2PreId() {
		return student2PreId;
	}

	public void setStudent2PreId(Integer student2PreId) {
		this.student2PreId = student2PreId;
	}

	public Integer getStudent3PreId() {
		return student3PreId;
	}

	public void setStudent3PreId(Integer student3PreId) {
		this.student3PreId = student3PreId;
	}

	public Integer getStudent1PostId() {
		return student1PostId;
	}

	public void setStudent1PostId(Integer student1PostId) {
		this.student1PostId = student1PostId;
	}

	public Integer getStudent2PostId() {
		return student2PostId;
	}

	public void setStudent2PostId(Integer student2PostId) {
		this.student2PostId = student2PostId;
	}

	public Integer getStudent3PostId() {
		return student3PostId;
	}

	public void setStudent3PostId(Integer student3PostId) {
		this.student3PostId = student3PostId;
	}

}
