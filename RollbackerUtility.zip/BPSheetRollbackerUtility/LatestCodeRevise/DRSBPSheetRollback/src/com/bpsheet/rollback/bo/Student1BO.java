package com.bpsheet.rollback.bo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STUD_DATA_1")
public class Student1BO implements Serializable {

	/**
	 * CREATE TABLE SM_Hibernate_1.STUD_DATA_1(ID INT(10) NOT NULL
	 * AUTO_INCREMENT,STUD_DATA_VAL VARCHAR(20),PRIMARY KEY(ID)); INSERT INTO
	 * SM_Hibernate_1.STUD_DATA_1(ID,STUD_DATA_VAL)VALUES(9,'SUDEEP'); SELECT * FROM
	 * SM_Hibernate_1.STUD_DATA_1;
	 */
	private static final long serialVersionUID = -2387856435355148187L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer id1;

	public Integer getId1() {
		return id1;
	}

	public void setId1(Integer id1) {
		this.id1 = id1;
	}

}
